# ITI121_assgn2 > 2025-12-23 11:33am
https://universe.roboflow.com/goldfish-yykih/iti121_assgn2

Provided by a Roboflow user
License: CC BY 4.0

